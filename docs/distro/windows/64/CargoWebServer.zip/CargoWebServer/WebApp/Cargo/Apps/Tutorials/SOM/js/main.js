
function main(){
    alert("Hello Cargo!")
}