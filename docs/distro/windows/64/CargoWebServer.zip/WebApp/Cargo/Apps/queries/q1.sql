/** Wrote your query here **/
select * from employe