var antlr4 = require('antlr4/index');

var HelloLexer = require('./generated/HelloLexer');
var HelloParser = require('./generated/HelloParser');
function sayHello(to){
	var chars = new antlr4.InputStream("hello " + to);
    console.log("--->" + chars)
	var lexer = new HelloLexer.HelloLexer(chars);
	var tokens  = new antlr4.CommonTokenStream(lexer);
	var parser = new HelloParser.HelloParser(tokens);
	parser.buildParseTrees = true;
	var tree = parser.r();
	console.log("Parsed: "+ tree);
	
}

sayHello("Cargo")
