var antlr4 = require('antlr4/index');
var fs = require('fs')

var TodoLexer = require('./generated-parser/todoLexer');
var TodoParser = require('./generated-parser/todoParser');
function readTodoLst(path){
	var input = fs.readFileSync(path,'ascii')
	console.log(input)
	var chars = new antlr4.InputStream(/**/ "* Ceci est un test");
	var lexer = new TodoLexer.todoLexer(chars);
	var tokens  = new antlr4.CommonTokenStream(lexer);
	var parser = new TodoParser.todoParser(tokens);
	parser.buildParseTrees = true;
	var tree = parser.elements();
	console.log("Parsed: "+ tree);
	
}

// Test read a file...
//readTodoLst("C:\\Temp\\todo.txt")
readTodoLst("/home/dave/Documents/todo.txt")